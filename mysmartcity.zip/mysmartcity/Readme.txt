How to run the Garbage Management System (GMS) Project

1. Download the  zip file

2. Extract the file and copy gms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name garbagemsdb

6. Import garbagemsdb.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/gms (frontend)



Credential for admin panel :

Username: admin
Password: Test@123

Credential for  driver panel :

Username: vams123
Password: Test@123
Or Register a new driver.

Credential for  User panel :

Username: Johndoe123
Password: Test@123
Or Register a new User.